import React from 'react';
import Layout from '@/components/Layout';
import ContactForm from '@/components/ContactForm';
import { IMG } from '@/lib/images';
import { Plane, ShoppingBag, Shirt, ChefHat, CalendarClock, Sparkles } from 'lucide-react';

const services = [
  { icon: Plane, t: 'Airport Pickup Coordination', d: 'Private transportation arranged to greet you the moment you land at Hartsfield-Jackson.' },
  { icon: ShoppingBag, t: 'Grocery Stocking', d: 'Your kitchen stocked to your exact specifications before arrival.' },
  { icon: Shirt, t: 'Laundry & Dry Cleaning', d: 'Coordinated pickup, cleaning, and delivery throughout your stay.' },
  { icon: ChefHat, t: 'Private Chef Referrals', d: 'Bespoke in-home dining experiences from Atlanta\'s finest vetted chefs.' },
  { icon: CalendarClock, t: 'Event Transportation', d: 'Reliable rides to matches, meetings, dinners, and private events.' },
  { icon: Sparkles, t: 'Housekeeping Coordination', d: 'Professional cleaning scheduled discreetly around your itinerary.' },
];

const Concierge: React.FC = () => (
  <Layout>
    <section className="relative h-[45vh] flex items-center">
      <img src={IMG.chef} alt="Concierge" className="absolute inset-0 w-full h-full object-cover" />
      <div className="absolute inset-0 bg-black/70" />
      <div className="relative max-w-5xl mx-auto px-5 text-center">
        <span className="text-[#D4AF37] tracking-[0.3em] text-xs uppercase">White-Glove Service</span>
        <h1 className="font-serif text-4xl md:text-5xl text-white mt-3">Concierge Services</h1>
        <p className="text-gray-300 mt-4 max-w-2xl mx-auto">Southern hospitality meets five-star service. Every detail handled, so you can simply enjoy Atlanta.</p>
      </div>
    </section>
    <section className="max-w-7xl mx-auto px-5 py-16">
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {services.map((s) => (
          <div key={s.t} className="bg-[#1f1f1f] border border-white/10 rounded-xl p-7 hover:border-[#D4AF37]/50 transition-colors">
            <div className="w-12 h-12 rounded-lg bg-[#D4AF37]/15 flex items-center justify-center mb-4"><s.icon className="text-[#D4AF37]" size={22} /></div>
            <h3 className="text-white font-medium text-lg mb-2">{s.t}</h3>
            <p className="text-gray-400 text-sm leading-relaxed">{s.d}</p>
          </div>
        ))}
      </div>
    </section>
    <section className="max-w-3xl mx-auto px-5 pb-20">
      <h2 className="font-serif text-3xl text-white text-center mb-6">Request Concierge Support</h2>
      <ContactForm defaultInterest="stay" source="concierge" />
    </section>
  </Layout>
);

export default Concierge;
