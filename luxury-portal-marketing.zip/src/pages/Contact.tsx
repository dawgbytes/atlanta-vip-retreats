import React from 'react';
import Layout from '@/components/Layout';
import ContactForm from '@/components/ContactForm';
import { BOOKING_URL } from '@/lib/images';
import { Phone, Mail, MapPin, Clock } from 'lucide-react';

const Contact: React.FC = () => (
  <Layout>
    <section className="bg-[#1a1a1a] py-16">
      <div className="max-w-7xl mx-auto px-5 text-center">
        <span className="text-[#D4AF37] tracking-[0.3em] text-xs uppercase">We're Here To Help</span>
        <h1 className="font-serif text-4xl md:text-5xl text-white mt-3">Contact Us</h1>
        <p className="text-gray-400 mt-4 max-w-2xl mx-auto">Whether you're planning a stay, exploring partnership, or coordinating transportation — our team is ready to assist.</p>
      </div>
    </section>
    <section className="max-w-7xl mx-auto px-5 py-16 grid lg:grid-cols-3 gap-12">
      <div className="space-y-6">
        {[
          { icon: Phone, t: 'Call Us', v: '(404) 555-0188' },
          { icon: Mail, t: 'Email', v: 'stay@atlantavipretreats.com' },
          { icon: MapPin, t: 'Location', v: 'Atlanta, Georgia' },
          { icon: Clock, t: 'Hours', v: '24/7 Concierge Support' },
        ].map((c) => (
          <div key={c.t} className="flex gap-4 items-start">
            <div className="w-11 h-11 rounded-lg bg-[#D4AF37]/15 flex items-center justify-center shrink-0"><c.icon className="text-[#D4AF37]" size={20} /></div>
            <div>
              <p className="text-white font-medium">{c.t}</p>
              <p className="text-gray-400 text-sm">{c.v}</p>
            </div>
          </div>
        ))}
        <a href={BOOKING_URL} target="_blank" rel="noopener noreferrer" className="inline-block w-full text-center bg-[#D4AF37] text-black font-medium px-6 py-3 rounded-lg hover:bg-[#c39e2e] transition-colors">Book a Call</a>
      </div>
      <div className="lg:col-span-2 bg-[#1f1f1f] border border-white/10 rounded-xl p-8">
        <h2 className="font-serif text-2xl text-white mb-6">Send Us a Message</h2>
        <ContactForm source="contact-page" />
      </div>
    </section>
  </Layout>
);

export default Contact;
