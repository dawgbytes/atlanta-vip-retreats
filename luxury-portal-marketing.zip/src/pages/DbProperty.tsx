import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import Layout from '@/components/Layout';
import ContactForm from '@/components/ContactForm';
import { supabase } from '@/lib/supabase';
import { IMG } from '@/lib/images';
import { BedDouble, Bath, Car, Briefcase, MapPin, Check, Loader2 } from 'lucide-react';

const DbProperty: React.FC = () => {
  const { id } = useParams();
  const [p, setP] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    supabase.from('properties').select('*').eq('id', id).single().then(({ data }) => { setP(data); setLoading(false); });
  }, [id]);

  if (loading) return <Layout><div className="py-32 text-center"><Loader2 className="animate-spin text-[#D4AF37] mx-auto" /></div></Layout>;
  if (!p) return <Layout><div className="py-32 text-center text-gray-400">Property not found.</div></Layout>;

  const photos: string[] = (p.photos && p.photos.length ? p.photos : [IMG.interior3]);
  const amenities = (p.amenities || '').split(',').map((a: string) => a.trim()).filter(Boolean);

  return (
    <Layout>
      <section className="relative h-[55vh]">
        <img src={photos[0]} alt={p.property_name} className="absolute inset-0 w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent" />
        <div className="absolute bottom-0 max-w-7xl mx-auto px-5 pb-10 left-0 right-0">
          <span className="text-xs px-3 py-1 rounded-full bg-[#D4AF37]/20 text-[#D4AF37] border border-[#D4AF37]/40">{p.status}</span>
          <h1 className="font-serif text-3xl md:text-5xl text-white mt-3">{p.property_name}</h1>
          <p className="text-gray-300 flex items-center gap-1 mt-2"><MapPin size={15} className="text-[#D4AF37]" /> {p.property_address || 'Atlanta, GA'}</p>
        </div>
      </section>
      <section className="max-w-7xl mx-auto px-5 py-14 grid lg:grid-cols-3 gap-12">
        <div className="lg:col-span-2">
          <div className="flex flex-wrap gap-6 pb-8 border-b border-white/10">
            <span className="flex items-center gap-2 text-gray-200"><BedDouble className="text-[#D4AF37]" /> {p.bedrooms} Bedrooms</span>
            <span className="flex items-center gap-2 text-gray-200"><Bath className="text-[#D4AF37]" /> {p.bathrooms} Bathrooms</span>
            <span className="flex items-center gap-2 text-gray-200"><Car className="text-[#D4AF37]" /> {p.parking} Parking</span>
            <span className="flex items-center gap-2 text-gray-200"><Briefcase className="text-[#D4AF37]" /> {p.office} Office</span>
          </div>
          <p className="text-gray-300 leading-relaxed mt-8 text-lg">{p.description}</p>
          {amenities.length > 0 && <>
            <h3 className="font-serif text-2xl text-white mt-10 mb-4">Amenities</h3>
            <div className="grid sm:grid-cols-2 gap-3">
              {amenities.map((a: string) => <span key={a} className="flex items-center gap-2 text-gray-300"><Check size={16} className="text-[#D4AF37]" /> {a}</span>)}
            </div>
          </>}
          {photos.length > 1 && <>
            <h3 className="font-serif text-2xl text-white mt-12 mb-4">Gallery</h3>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              {photos.map((g, i) => <img key={i} src={g} alt={`${i}`} className="rounded-lg object-cover h-40 w-full" />)}
            </div>
          </>}
        </div>
        <div>
          <div className="bg-[#1f1f1f] border border-white/10 rounded-xl p-7 sticky top-28">
            {p.nightly_rate ? <p className="text-[#D4AF37] text-2xl font-serif mb-1">From ${p.nightly_rate}<span className="text-base text-gray-400">/night</span></p> : null}
            <h3 className="font-serif text-xl text-white mb-4">Inquire About This Stay</h3>
            <ContactForm compact defaultInterest="stay" source={`db-property-${id}`} />
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default DbProperty;
