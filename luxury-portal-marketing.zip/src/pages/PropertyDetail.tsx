import React from 'react';
import { useParams } from 'react-router-dom';
import Layout from '@/components/Layout';
import ContactForm from '@/components/ContactForm';
import { IMG } from '@/lib/images';
import { BedDouble, Bath, Car, Briefcase, MapPin, Check } from 'lucide-react';

const data: Record<string, any> = {
  dunwoody: {
    name: 'Dunwoody Executive Retreat',
    location: 'Chamblee Dunwoody Road, Atlanta / Dunwoody',
    status: 'Available for inquiry',
    beds: 6, baths: 4, parking: 4, office: 1, rate: 895,
    desc: 'A large private home positioned for World Cup visitors, families, executives, and group travelers. Generous living spaces, refined interiors, and a prime Dunwoody location offer the perfect base for an elevated Atlanta stay.',
    amenities: ['Chef\'s kitchen', 'High-speed WiFi', 'Home office', 'Spacious living areas', 'Premium linens', 'Smart TVs', 'Private parking', 'Outdoor patio'],
    gallery: [IMG.homeExt1, IMG.interior1, IMG.interior2, IMG.interior3, IMG.interior4, IMG.chef],
  },
  'upper-westside': {
    name: 'Upper Westside Executive Retreat',
    location: 'Defoor Ave, West Midtown Atlanta',
    status: 'Coming Soon',
    beds: 5, baths: 4, parking: 3, office: 1, rate: null,
    comingSoon: true,
    desc: 'An exclusive West Midtown residence launching soon. Available by private inquiry only. Register your interest to be among the first notified when this property opens.',
    amenities: ['Modern design', 'WiFi', 'Office space', 'Walkable district', 'Designer furnishings'],
    gallery: [IMG.homeExt2, IMG.interior4, IMG.interior2],
  },
};

const PropertyDetail: React.FC = () => {
  const { slug } = useParams();
  const p = data[slug || 'dunwoody'];
  if (!p) return <Layout><div className="max-w-7xl mx-auto px-5 py-32 text-center text-gray-400">Property not found.</div></Layout>;

  return (
    <Layout>
      <section className="relative h-[55vh]">
        <img src={p.gallery[0]} alt={p.name} className="absolute inset-0 w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent" />
        <div className="absolute bottom-0 max-w-7xl mx-auto px-5 pb-10 left-0 right-0">
          <span className="text-xs px-3 py-1 rounded-full bg-[#D4AF37]/20 text-[#D4AF37] border border-[#D4AF37]/40">{p.status}</span>
          <h1 className="font-serif text-3xl md:text-5xl text-white mt-3">{p.name}</h1>
          <p className="text-gray-300 flex items-center gap-1 mt-2"><MapPin size={15} className="text-[#D4AF37]" /> {p.location}</p>
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-5 py-14 grid lg:grid-cols-3 gap-12">
        <div className="lg:col-span-2">
          <div className="flex flex-wrap gap-6 pb-8 border-b border-white/10">
            <span className="flex items-center gap-2 text-gray-200"><BedDouble className="text-[#D4AF37]" /> {p.beds} Bedrooms</span>
            <span className="flex items-center gap-2 text-gray-200"><Bath className="text-[#D4AF37]" /> {p.baths} Bathrooms</span>
            <span className="flex items-center gap-2 text-gray-200"><Car className="text-[#D4AF37]" /> {p.parking} Parking</span>
            <span className="flex items-center gap-2 text-gray-200"><Briefcase className="text-[#D4AF37]" /> {p.office} Office</span>
          </div>
          <p className="text-gray-300 leading-relaxed mt-8 text-lg">{p.desc}</p>
          <h3 className="font-serif text-2xl text-white mt-10 mb-4">Amenities</h3>
          <div className="grid sm:grid-cols-2 gap-3">
            {p.amenities.map((a: string) => (
              <span key={a} className="flex items-center gap-2 text-gray-300"><Check size={16} className="text-[#D4AF37]" /> {a}</span>
            ))}
          </div>
          <h3 className="font-serif text-2xl text-white mt-12 mb-4">Gallery</h3>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            {p.gallery.map((g: string, i: number) => (
              <img key={i} src={g} alt={`${p.name} ${i}`} className="rounded-lg object-cover h-40 w-full hover:opacity-90 transition-opacity" />
            ))}
          </div>
        </div>
        <div className="lg:col-span-1">
          <div className="bg-[#1f1f1f] border border-white/10 rounded-xl p-7 sticky top-28">
            {p.rate && <p className="text-[#D4AF37] text-2xl font-serif mb-1">From ${p.rate}<span className="text-base text-gray-400">/night</span></p>}
            <h3 className="font-serif text-xl text-white mb-4">{p.comingSoon ? 'Private Inquiry' : 'Inquire About This Stay'}</h3>
            <ContactForm compact defaultInterest="stay" source={`property-${slug}`} />
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default PropertyDetail;
