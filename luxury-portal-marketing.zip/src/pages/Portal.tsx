import React, { useEffect, useState } from 'react';
import Layout from '@/components/Layout';
import PropertyForm from '@/components/PropertyForm';
import MarketingOutputs from '@/components/MarketingOutputs';
import { supabase } from '@/lib/supabase';
import { Plus, LayoutDashboard, Home, Inbox, Sparkles, Pencil, Trash2, ExternalLink, LogOut, Loader2 } from 'lucide-react';
import { Link } from 'react-router-dom';

type Tab = 'dashboard' | 'add' | 'leads';
const statusClasses: Record<string, string> = { Active: 'bg-green-500/20 text-green-300', 'Coming Soon': 'bg-blue-500/20 text-blue-300', Inactive: 'bg-gray-500/20 text-gray-300' };
const input = "w-full bg-[#161616] border border-white/15 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:border-[#D4AF37] focus:outline-none";

const Auth: React.FC<{ onAuthed: () => void }> = ({ onAuthed }) => {
  const [mode, setMode] = useState<'login' | 'signup'>('login');
  const [email, setEmail] = useState(''); const [pass, setPass] = useState('');
  const [err, setErr] = useState(''); const [busy, setBusy] = useState(false);
  const submit = async (e: React.FormEvent) => {
    e.preventDefault(); setErr(''); setBusy(true);
    const fn = mode === 'login' ? supabase.auth.signInWithPassword : supabase.auth.signUp;
    const { error } = await fn({ email, password: pass });
    setBusy(false);
    if (error) setErr(error.message); else onAuthed();
  };
  return (
    <div className="max-w-md mx-auto px-5 py-20">
      <div className="bg-[#1f1f1f] border border-white/10 rounded-xl p-8">
        <h2 className="font-serif text-2xl text-white mb-1">{mode === 'login' ? 'Owner Sign In' : 'Create Owner Account'}</h2>
        <p className="text-gray-400 text-sm mb-6">Access your property marketing & management portal.</p>
        <form onSubmit={submit} className="space-y-4">
          <input className={input} type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} required />
          <input className={input} type="password" placeholder="Password" value={pass} onChange={(e) => setPass(e.target.value)} required />
          {err && <p className="text-red-400 text-sm">{err}</p>}
          <button disabled={busy} className="w-full bg-[#D4AF37] text-black font-medium py-3 rounded-lg hover:bg-[#c39e2e] flex items-center justify-center gap-2 disabled:opacity-60">{busy && <Loader2 className="animate-spin" size={16} />} {mode === 'login' ? 'Sign In' : 'Sign Up'}</button>
        </form>
        <button onClick={() => setMode(mode === 'login' ? 'signup' : 'login')} className="text-[#D4AF37] text-sm mt-4 hover:underline">{mode === 'login' ? "Need an account? Sign up" : 'Have an account? Sign in'}</button>
      </div>
    </div>
  );
};

const Portal: React.FC = () => {
  const [session, setSession] = useState<any>(null);
  const [ready, setReady] = useState(false);
  const [tab, setTab] = useState<Tab>('dashboard');
  const [properties, setProperties] = useState<any[]>([]);
  const [leads, setLeads] = useState<any[]>([]);
  const [editing, setEditing] = useState<any>(null);
  const [marketing, setMarketing] = useState<any>(null);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => { setSession(data.session); setReady(true); });
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => setSession(s));
    return () => sub.subscription.unsubscribe();
  }, []);

  const uid = session?.user?.id;
  const load = async () => {
    if (!uid) return;
    const { data: p } = await supabase.from('properties').select('*').eq('owner_id', uid).order('created_at', { ascending: false });
    setProperties(p || []);
    const { data: l } = await supabase.from('leads').select('*').eq('owner_id', uid).order('created_at', { ascending: false });
    setLeads(l || []);
  };
  useEffect(() => { if (uid) load(); }, [uid]);

  const del = async (id: string) => { await supabase.from('properties').delete().eq('id', id); load(); };
  const setStatus = async (id: string, status: string) => { await supabase.from('properties').update({ status }).eq('id', id); load(); };
  const setLeadStatus = async (id: string, status: string) => { await supabase.from('leads').update({ status }).eq('id', id); load(); };

  if (!ready) return <Layout><div className="py-32 text-center"><Loader2 className="animate-spin text-[#D4AF37] mx-auto" /></div></Layout>;
  if (!session) return <Layout><Auth onAuthed={() => {}} /></Layout>;

  const tabs = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'add', label: editing ? 'Edit Property' : 'Add Property', icon: Plus },
    { id: 'leads', label: 'Leads', icon: Inbox },
  ];

  return (
    <Layout>
      <section className="bg-[#1a1a1a] py-10 border-b border-white/10">
        <div className="max-w-7xl mx-auto px-5 flex justify-between items-end flex-wrap gap-4">
          <div>
            <span className="text-[#D4AF37] tracking-[0.3em] text-xs uppercase">Marketing & Management</span>
            <h1 className="font-serif text-3xl md:text-4xl text-white mt-2">Owner Portal</h1>
            <p className="text-gray-400 mt-2 text-sm">{session.user.email}</p>
          </div>
          <button onClick={() => supabase.auth.signOut()} className="flex items-center gap-2 text-gray-400 hover:text-white text-sm border border-white/15 px-4 py-2 rounded-lg"><LogOut size={15} /> Sign Out</button>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-5 py-8">
        <div className="flex gap-3 mb-8 border-b border-white/10">
          {tabs.map((t) => (
            <button key={t.id} onClick={() => { setTab(t.id as Tab); if (t.id !== 'add') setEditing(null); }} className={`flex items-center gap-2 px-4 py-3 text-sm border-b-2 -mb-px transition-colors ${tab === t.id ? 'border-[#D4AF37] text-[#D4AF37]' : 'border-transparent text-gray-400 hover:text-white'}`}><t.icon size={16} /> {t.label}</button>
          ))}
        </div>

        {tab === 'dashboard' && (
          <div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
              {[{ l: 'Total Properties', v: properties.length }, { l: 'Active', v: properties.filter((p) => p.status === 'Active').length }, { l: 'Coming Soon', v: properties.filter((p) => p.status === 'Coming Soon').length }, { l: 'Total Leads', v: leads.length }].map((s) => (
                <div key={s.l} className="bg-[#1f1f1f] border border-white/10 rounded-xl p-5"><p className="font-serif text-3xl text-[#D4AF37]">{s.v}</p><p className="text-gray-400 text-sm mt-1">{s.l}</p></div>
              ))}
            </div>
            {properties.length === 0 ? (
              <div className="text-center py-16 text-gray-400"><Home className="mx-auto mb-3 text-[#D4AF37]" /><p>No properties yet. Add your first property to generate marketing materials.</p><button onClick={() => setTab('add')} className="mt-4 bg-[#D4AF37] text-black px-5 py-2.5 rounded-lg font-medium">Add Property</button></div>
            ) : (
              <div className="space-y-4">
                {properties.map((p) => (
                  <div key={p.id} className="bg-[#1f1f1f] border border-white/10 rounded-xl p-5 flex flex-col md:flex-row gap-5 md:items-center">
                    <img src={(p.photos && p.photos[0]) || 'https://d64gsuwffb70l.cloudfront.net/6a211cfc56545a9a21240ba2_1780555203303_edd96ade.jpg'} alt={p.property_name} className="w-full md:w-40 h-28 object-cover rounded-lg" />
                    <div className="flex-1">
                      <div className="flex items-center gap-3 flex-wrap"><h3 className="font-serif text-xl text-white">{p.property_name}</h3><span className={`text-xs px-2.5 py-1 rounded-full ${statusClasses[p.status] || ''}`}>{p.status}</span></div>
                      <p className="text-gray-400 text-sm mt-1">{p.property_address || 'Atlanta, GA'} · {p.bedrooms}BR / {p.bathrooms}BA · ${p.nightly_rate}/night</p>
                      <div className="flex gap-2 mt-3 flex-wrap">{['Coming Soon', 'Active', 'Inactive'].map((s) => (<button key={s} onClick={() => setStatus(p.id, s)} className={`text-xs px-2.5 py-1 rounded border ${p.status === s ? 'border-[#D4AF37] text-[#D4AF37]' : 'border-white/15 text-gray-400 hover:text-white'}`}>{s}</button>))}</div>
                    </div>
                    <div className="flex gap-2">
                      <button onClick={() => setMarketing(marketing?.id === p.id ? null : p)} className="flex items-center gap-1 text-sm bg-[#D4AF37]/15 text-[#D4AF37] px-3 py-2 rounded-lg hover:bg-[#D4AF37]/25"><Sparkles size={15} /> Marketing</button>
                      <Link to={`/properties/db/${p.id}`} className="p-2 text-gray-400 hover:text-white"><ExternalLink size={17} /></Link>
                      <button onClick={() => { setEditing(p); setTab('add'); }} className="p-2 text-gray-400 hover:text-white"><Pencil size={17} /></button>
                      <button onClick={() => del(p.id)} className="p-2 text-gray-400 hover:text-red-400"><Trash2 size={17} /></button>
                    </div>
                    {marketing?.id === p.id && <div className="w-full md:basis-full mt-2"><MarketingOutputs property={p} /></div>}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {tab === 'add' && (
          <div className="bg-[#1f1f1f] border border-white/10 rounded-xl p-6 max-w-4xl">
            <PropertyForm initial={editing} ownerId={uid} onSaved={() => { setEditing(null); setTab('dashboard'); load(); }} />
          </div>
        )}

        {tab === 'leads' && (
          <div className="bg-[#1f1f1f] border border-white/10 rounded-xl overflow-hidden">
            {leads.length === 0 ? <p className="p-10 text-center text-gray-400">No leads yet.</p> : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-[#161616] text-gray-400 text-left"><tr><th className="p-4">Name</th><th className="p-4">Contact</th><th className="p-4">Interest</th><th className="p-4">Message</th><th className="p-4">Status</th></tr></thead>
                  <tbody>
                    {leads.map((l) => (
                      <tr key={l.id} className="border-t border-white/10">
                        <td className="p-4 text-white">{l.name}</td>
                        <td className="p-4 text-gray-400">{l.email}<br />{l.phone}</td>
                        <td className="p-4 text-gray-300 capitalize">{l.interest}</td>
                        <td className="p-4 text-gray-400 max-w-xs truncate">{l.message}</td>
                        <td className="p-4"><select value={l.status} onChange={(e) => setLeadStatus(l.id, e.target.value)} className="bg-[#161616] border border-white/15 rounded px-2 py-1 text-gray-300"><option>New</option><option>Contacted</option><option>Booked</option><option>Closed</option></select></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}
      </div>
    </Layout>
  );
};

export default Portal;
