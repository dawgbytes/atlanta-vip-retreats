import React from 'react';
import Layout from '@/components/Layout';
import ContactForm from '@/components/ContactForm';
import { IMG } from '@/lib/images';
import { Trophy, Users, Calendar, MapPin } from 'lucide-react';

const stats = [
  { icon: Trophy, n: '8', l: 'Matches Hosted' },
  { icon: Users, n: '300K+', l: 'Expected Visitors' },
  { icon: Calendar, n: '2026', l: 'Tournament Year' },
  { icon: MapPin, n: '1', l: 'Mercedes-Benz Stadium' },
];

const WorldCup: React.FC = () => (
  <Layout>
    <section className="relative h-[60vh] flex items-center">
      <img src={IMG.stadium} alt="Stadium" className="absolute inset-0 w-full h-full object-cover" />
      <div className="absolute inset-0 bg-black/75" />
      <div className="relative max-w-5xl mx-auto px-5 text-center">
        <span className="text-[#D4AF37] tracking-[0.3em] text-xs uppercase">FIFA World Cup 2026</span>
        <h1 className="font-serif text-4xl md:text-6xl text-white mt-4">The World Comes to Atlanta</h1>
        <p className="text-gray-300 text-lg mt-5 max-w-3xl mx-auto">Atlanta hosts eight FIFA World Cup matches at Mercedes-Benz Stadium in 2026. Demand for premium accommodations will be extraordinary — secure your luxury stay now.</p>
      </div>
    </section>

    <section className="max-w-7xl mx-auto px-5 py-16 grid grid-cols-2 md:grid-cols-4 gap-6">
      {stats.map((s) => (
        <div key={s.l} className="bg-[#1f1f1f] border border-white/10 rounded-xl p-7 text-center">
          <s.icon className="text-[#D4AF37] mx-auto mb-3" size={28} />
          <p className="font-serif text-3xl text-white">{s.n}</p>
          <p className="text-gray-400 text-sm mt-1">{s.l}</p>
        </div>
      ))}
    </section>

    <section className="max-w-7xl mx-auto px-5 pb-16 grid md:grid-cols-2 gap-12 items-center">
      <div>
        <h2 className="font-serif text-3xl md:text-4xl text-white mb-4">Why Book Early?</h2>
        <ul className="space-y-4 text-gray-300">
          <li>· Limited luxury inventory across Atlanta's premier neighborhoods</li>
          <li>· Group-friendly homes for families, executives, and corporate delegations</li>
          <li>· Concierge and transportation coordination to every match</li>
          <li>· Walkable and stadium-adjacent options for the ultimate fan experience</li>
          <li>· Flexible multi-night packages with white-glove service</li>
        </ul>
      </div>
      <img src={IMG.interior1} alt="Luxury interior" className="rounded-xl object-cover h-80 w-full" />
    </section>

    <section className="max-w-3xl mx-auto px-5 pb-20">
      <div className="bg-[#1f1f1f] border border-[#D4AF37]/30 rounded-xl p-8">
        <h2 className="font-serif text-2xl md:text-3xl text-white text-center mb-2">Inquire for World Cup Housing</h2>
        <p className="text-gray-400 text-center mb-6">Tell us your dates, group size, and preferences. Our team will match you with the perfect retreat.</p>
        <ContactForm defaultInterest="stay" source="world-cup" />
      </div>
    </section>
  </Layout>
);

export default WorldCup;
