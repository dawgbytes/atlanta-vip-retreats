import React from 'react';
import Layout from '@/components/Layout';
import ContactForm from '@/components/ContactForm';
import { IMG } from '@/lib/images';
import { Plane, Trophy, Building2, Users, Check } from 'lucide-react';

const offerings = [
  { icon: Plane, t: 'Airport Transfers', d: 'Private SUV and luxury sedan transfers to and from Hartsfield-Jackson International.' },
  { icon: Trophy, t: 'Match-Day Transport', d: 'Coordinated rides to Mercedes-Benz Stadium for every World Cup match.' },
  { icon: Building2, t: 'Corporate Travel', d: 'Executive transportation for meetings, conferences, and business itineraries.' },
  { icon: Users, t: 'Group & Event Rides', d: 'Sprinter vans and fleet coordination for families and group travelers.' },
];

const Transportation: React.FC = () => (
  <Layout>
    <section className="relative h-[45vh] flex items-center">
      <img src={IMG.transport} alt="Transportation" className="absolute inset-0 w-full h-full object-cover" />
      <div className="absolute inset-0 bg-black/70" />
      <div className="relative max-w-5xl mx-auto px-5 text-center">
        <span className="text-[#D4AF37] tracking-[0.3em] text-xs uppercase">Move With Ease</span>
        <h1 className="font-serif text-4xl md:text-5xl text-white mt-3">Transportation Coordination</h1>
        <p className="text-gray-300 mt-4 max-w-2xl mx-auto">Seamless, reliable, and refined transportation throughout your Atlanta stay.</p>
      </div>
    </section>
    <section className="max-w-7xl mx-auto px-5 py-16 grid sm:grid-cols-2 gap-6">
      {offerings.map((o) => (
        <div key={o.t} className="bg-[#1f1f1f] border border-white/10 rounded-xl p-7 flex gap-5">
          <div className="w-12 h-12 shrink-0 rounded-lg bg-[#D4AF37]/15 flex items-center justify-center"><o.icon className="text-[#D4AF37]" size={22} /></div>
          <div>
            <h3 className="text-white font-medium text-lg mb-1">{o.t}</h3>
            <p className="text-gray-400 text-sm leading-relaxed">{o.d}</p>
          </div>
        </div>
      ))}
    </section>
    <section className="max-w-7xl mx-auto px-5 pb-10">
      <div className="bg-[#1a1a1a] rounded-xl p-8 grid md:grid-cols-2 gap-6">
        {['Professional, vetted drivers', 'Flexible scheduling', 'Luxury vehicle fleet', 'Coordinated with your itinerary'].map((b) => (
          <span key={b} className="flex items-center gap-2 text-gray-300"><Check className="text-[#D4AF37]" size={18} /> {b}</span>
        ))}
      </div>
    </section>
    <section className="max-w-3xl mx-auto px-5 pb-20">
      <h2 className="font-serif text-3xl text-white text-center mb-6">Arrange Transportation</h2>
      <ContactForm defaultInterest="transportation" source="transportation" />
    </section>
  </Layout>
);

export default Transportation;
