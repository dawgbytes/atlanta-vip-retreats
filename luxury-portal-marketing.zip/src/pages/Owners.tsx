import React from 'react';
import { Link } from 'react-router-dom';
import Layout from '@/components/Layout';
import ContactForm from '@/components/ContactForm';
import { IMG, BOOKING_URL } from '@/lib/images';
import { ClipboardCheck, TrendingUp, DollarSign, Megaphone, ArrowRight } from 'lucide-react';

const steps = [
  { icon: ClipboardCheck, t: 'Prepare', d: 'We assess and stage your home to meet luxury-stay standards.' },
  { icon: TrendingUp, t: 'Position', d: 'Strategic positioning for World Cup, corporate, and event demand.' },
  { icon: DollarSign, t: 'Price', d: 'Dynamic, data-informed pricing to maximize revenue per night.' },
  { icon: Megaphone, t: 'Market', d: 'Multi-platform listings and marketing across Airbnb, VRBO & Booking.com.' },
];

const Owners: React.FC = () => (
  <Layout>
    <section className="relative h-[50vh] flex items-center">
      <img src={IMG.homeExt2} alt="Owner property" className="absolute inset-0 w-full h-full object-cover" />
      <div className="absolute inset-0 bg-gradient-to-r from-black/85 to-black/40" />
      <div className="relative max-w-7xl mx-auto px-5">
        <span className="text-[#D4AF37] tracking-[0.3em] text-xs uppercase">Partner With Us</span>
        <h1 className="font-serif text-4xl md:text-6xl text-white mt-3 max-w-2xl">Turn Your Home Into a High-Performing Asset</h1>
        <p className="text-gray-300 mt-5 max-w-xl">We help owners prepare, position, price, and market homes for event-based and luxury short-term rental demand.</p>
      </div>
    </section>

    <section className="max-w-7xl mx-auto px-5 py-16">
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {steps.map((s, i) => (
          <div key={s.t} className="bg-[#1f1f1f] border border-white/10 rounded-xl p-7">
            <span className="text-[#D4AF37] font-serif text-3xl">0{i + 1}</span>
            <s.icon className="text-[#D4AF37] my-3" size={26} />
            <h3 className="text-white font-medium text-lg mb-1">{s.t}</h3>
            <p className="text-gray-400 text-sm leading-relaxed">{s.d}</p>
          </div>
        ))}
      </div>
    </section>

    <section className="bg-[#1a1a1a] py-16">
      <div className="max-w-5xl mx-auto px-5 text-center">
        <h2 className="font-serif text-3xl md:text-4xl text-white mb-4">Marketing & Management Portal</h2>
        <p className="text-gray-300 max-w-2xl mx-auto mb-8">Enter your property details once and instantly generate a property page, PDF flyer, owner packet, platform listings, social captions, and a management agreement draft — all in our Owner Portal.</p>
        <div className="flex flex-wrap justify-center gap-4">
          <Link to="/portal" className="inline-flex items-center gap-2 bg-[#D4AF37] text-black font-medium px-7 py-3.5 rounded-lg hover:bg-[#c39e2e] transition-colors">Open Owner Portal <ArrowRight size={18} /></Link>
          <a href={BOOKING_URL} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 border border-white/40 text-white px-7 py-3.5 rounded-lg hover:bg-white hover:text-black transition-colors">Book a Consultation</a>
        </div>
      </div>
    </section>

    <section className="max-w-3xl mx-auto px-5 py-20">
      <h2 className="font-serif text-3xl text-white text-center mb-6">Become a Partner Owner</h2>
      <ContactForm defaultInterest="property owner" source="owners" />
    </section>
  </Layout>
);

export default Owners;
