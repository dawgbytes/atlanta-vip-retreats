import React, { useEffect, useState } from 'react';
import Layout from '@/components/Layout';
import PropertyCard from '@/components/PropertyCard';
import { IMG } from '@/lib/images';
import { supabase } from '@/lib/supabase';

const future = ['Stadium District', 'Midtown', 'Buckhead', 'Sandy Springs', 'Dunwoody'];

const Properties: React.FC = () => {
  const [dbProps, setDbProps] = useState<any[]>([]);
  useEffect(() => {
    supabase.from('properties').select('*').neq('status', 'Inactive').order('created_at', { ascending: false }).then(({ data }) => setDbProps(data || []));
  }, []);

  return (
    <Layout>
      <section className="bg-[#1a1a1a] py-16">
        <div className="max-w-7xl mx-auto px-5 text-center">
          <span className="text-[#D4AF37] tracking-[0.3em] text-xs uppercase">Our Portfolio</span>
          <h1 className="font-serif text-4xl md:text-5xl text-white mt-3">Properties</h1>
          <p className="text-gray-400 mt-4 max-w-2xl mx-auto">A curated collection of Atlanta's finest luxury homes — perfect for World Cup visitors, executives, and group travelers.</p>
        </div>
      </section>
      <section className="max-w-7xl mx-auto px-5 py-16">
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          <PropertyCard name="Dunwoody Executive Retreat" location="Chamblee Dunwoody Road, Dunwoody" image={IMG.homeExt1} status="Available for inquiry" beds={6} baths={4} parking={4} to="/properties/dunwoody" rate={895} />
          <PropertyCard name="Upper Westside Executive Retreat" location="Defoor Ave, West Midtown" image={IMG.homeExt2} status="Coming Soon" beds={5} baths={4} parking={3} to="/properties/upper-westside" />
          {dbProps.map((p) => (
            <PropertyCard key={p.id} name={p.property_name} location={p.property_address || 'Atlanta, GA'} image={(p.photos && p.photos[0]) || IMG.interior3} status={p.status} beds={p.bedrooms} baths={p.bathrooms} parking={p.parking} rate={p.nightly_rate} to={`/properties/db/${p.id}`} />
          ))}
        </div>
        <div className="mt-16">
          <h2 className="font-serif text-2xl md:text-3xl text-white text-center mb-6">Future Atlanta Locations</h2>
          <div className="flex flex-wrap justify-center gap-3">
            {future.map((f) => <span key={f} className="px-5 py-2.5 rounded-full bg-[#1f1f1f] border border-[#D4AF37]/30 text-gray-300 text-sm">{f}</span>)}
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default Properties;
