import React, { useState } from 'react';
import { supabase } from '@/lib/supabase';
import PhotoUploader from './PhotoUploader';
import { Loader2, Save } from 'lucide-react';

interface Props { initial?: any; ownerId?: string; onSaved: () => void; }

const blank = {
  property_name: '', property_address: '', owner_name: '', manager_name: '',
  bedrooms: 0, bathrooms: 0, office: 0, parking: 0, amenities: '', description: '',
  nightly_rate: 0, cleaning_fee: 0, photos: [] as string[],
  transportation_available: false, laundry_available: false, concierge_available: false, status: 'Coming Soon',
};

const PropertyForm: React.FC<Props> = ({ initial, ownerId, onSaved }) => {
  const [f, setF] = useState<any>(initial || blank);
  const [saving, setSaving] = useState(false);
  const set = (k: string, v: any) => setF({ ...f, [k]: v });
  const input = "w-full bg-[#161616] border border-white/15 rounded-lg px-4 py-2.5 text-white placeholder-gray-500 focus:border-[#D4AF37] focus:outline-none";
  const label = "block text-sm text-gray-300 mb-1.5";

  const save = async () => {
    if (!f.property_name) return;
    setSaving(true);
    const payload: any = {
      property_name: f.property_name, property_address: f.property_address, owner_name: f.owner_name,
      manager_name: f.manager_name, bedrooms: Number(f.bedrooms), bathrooms: Number(f.bathrooms),
      office: Number(f.office), parking: Number(f.parking), amenities: f.amenities, description: f.description,
      nightly_rate: Number(f.nightly_rate), cleaning_fee: Number(f.cleaning_fee), photos: f.photos,
      transportation_available: f.transportation_available, laundry_available: f.laundry_available,
      concierge_available: f.concierge_available, status: f.status, owner_id: ownerId,
    };
    if (f.id) await supabase.from('properties').update(payload).eq('id', f.id);
    else await supabase.from('properties').insert(payload);
    setSaving(false); onSaved();
  };

  return (
    <div className="space-y-5">
      <div className="grid md:grid-cols-2 gap-4">
        <div><label className={label}>Property Name *</label><input className={input} value={f.property_name} onChange={(e) => set('property_name', e.target.value)} /></div>
        <div><label className={label}>Property Address</label><input className={input} value={f.property_address} onChange={(e) => set('property_address', e.target.value)} /></div>
        <div><label className={label}>Owner Name</label><input className={input} value={f.owner_name} onChange={(e) => set('owner_name', e.target.value)} /></div>
        <div><label className={label}>Manager Name</label><input className={input} value={f.manager_name} onChange={(e) => set('manager_name', e.target.value)} /></div>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div><label className={label}>Bedrooms</label><input type="number" className={input} value={f.bedrooms} onChange={(e) => set('bedrooms', e.target.value)} /></div>
        <div><label className={label}>Bathrooms</label><input type="number" step="0.5" className={input} value={f.bathrooms} onChange={(e) => set('bathrooms', e.target.value)} /></div>
        <div><label className={label}>Office</label><input type="number" className={input} value={f.office} onChange={(e) => set('office', e.target.value)} /></div>
        <div><label className={label}>Parking</label><input type="number" className={input} value={f.parking} onChange={(e) => set('parking', e.target.value)} /></div>
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div><label className={label}>Nightly Rate ($)</label><input type="number" className={input} value={f.nightly_rate} onChange={(e) => set('nightly_rate', e.target.value)} /></div>
        <div><label className={label}>Cleaning Fee ($)</label><input type="number" className={input} value={f.cleaning_fee} onChange={(e) => set('cleaning_fee', e.target.value)} /></div>
      </div>
      <div><label className={label}>Amenities (comma separated)</label><input className={input} value={f.amenities} onChange={(e) => set('amenities', e.target.value)} placeholder="WiFi, Chef's kitchen, Pool..." /></div>
      <div><label className={label}>Description</label><textarea rows={4} className={input} value={f.description} onChange={(e) => set('description', e.target.value)} /></div>
      <div className="grid grid-cols-3 gap-4">
        {[['transportation_available', 'Transportation'], ['laundry_available', 'Laundry'], ['concierge_available', 'Concierge']].map(([k, l]) => (
          <label key={k} className="flex items-center gap-2 text-sm text-gray-300 cursor-pointer"><input type="checkbox" checked={f[k]} onChange={(e) => set(k, e.target.checked)} className="accent-[#D4AF37] w-4 h-4" /> {l}</label>
        ))}
      </div>
      <div><label className={label}>Status</label><select className={input} value={f.status} onChange={(e) => set('status', e.target.value)}><option>Coming Soon</option><option>Active</option><option>Inactive</option></select></div>
      <div><label className={label}>Photos</label><PhotoUploader photos={f.photos || []} onChange={(p) => set('photos', p)} /></div>
      <button onClick={save} disabled={saving} className="flex items-center gap-2 bg-[#D4AF37] text-black px-6 py-3 rounded-lg font-medium hover:bg-[#c39e2e] disabled:opacity-60">{saving ? <Loader2 className="animate-spin" size={18} /> : <Save size={18} />} Save Property</button>
    </div>
  );
};

export default PropertyForm;
