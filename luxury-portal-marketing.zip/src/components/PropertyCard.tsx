import React from 'react';
import { Link } from 'react-router-dom';
import { BedDouble, Bath, Car, MapPin } from 'lucide-react';

interface Props {
  name: string;
  location: string;
  image: string;
  status: string;
  beds?: number;
  baths?: number;
  parking?: number;
  to?: string;
  rate?: number;
}

const statusColor: Record<string, string> = {
  'Active': 'bg-green-500/20 text-green-300 border-green-500/40',
  'Available for inquiry': 'bg-[#D4AF37]/20 text-[#D4AF37] border-[#D4AF37]/40',
  'Coming Soon': 'bg-blue-500/20 text-blue-300 border-blue-500/40',
  'Inactive': 'bg-gray-500/20 text-gray-300 border-gray-500/40',
};

const PropertyCard: React.FC<Props> = ({ name, location, image, status, beds, baths, parking, to, rate }) => {
  const content = (
    <div className="group bg-[#1f1f1f] rounded-xl overflow-hidden border border-white/10 hover:border-[#D4AF37]/50 transition-all h-full">
      <div className="relative h-60 overflow-hidden">
        <img src={image} alt={name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
        <span className={`absolute top-4 left-4 text-xs px-3 py-1 rounded-full border ${statusColor[status] || statusColor['Coming Soon']}`}>{status}</span>
      </div>
      <div className="p-6">
        <h3 className="font-serif text-xl text-white mb-1">{name}</h3>
        <p className="text-sm text-gray-400 flex items-center gap-1 mb-4"><MapPin size={13} className="text-[#D4AF37]" /> {location}</p>
        <div className="flex gap-5 text-sm text-gray-300">
          {beds != null && <span className="flex items-center gap-1"><BedDouble size={15} className="text-[#D4AF37]" /> {beds}</span>}
          {baths != null && <span className="flex items-center gap-1"><Bath size={15} className="text-[#D4AF37]" /> {baths}</span>}
          {parking != null && <span className="flex items-center gap-1"><Car size={15} className="text-[#D4AF37]" /> {parking}</span>}
        </div>
        {rate ? <p className="mt-4 text-[#D4AF37] font-medium">From ${rate}/night</p> : null}
      </div>
    </div>
  );
  return to ? <Link to={to}>{content}</Link> : content;
};

export default PropertyCard;
