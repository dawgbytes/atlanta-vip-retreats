import React, { useState } from 'react';
import { Copy, Check, FileDown, Globe, FileText, Share2, ScrollText, Package } from 'lucide-react';
import { airbnbDescription, vrboDescription, bookingDescription, socialCaption, websiteListing, ownerPacket, managementAgreement, PropertyData } from '@/lib/marketing';

const CopyBlock: React.FC<{ icon: any; title: string; text: string }> = ({ icon: Icon, title, text }) => {
  const [copied, setCopied] = useState(false);
  const copy = () => { navigator.clipboard.writeText(text); setCopied(true); setTimeout(() => setCopied(false), 1500); };
  return (
    <div className="bg-[#1f1f1f] border border-white/10 rounded-xl p-5">
      <div className="flex items-center justify-between mb-3">
        <h4 className="text-white font-medium flex items-center gap-2"><Icon size={16} className="text-[#D4AF37]" /> {title}</h4>
        <button onClick={copy} className="text-xs flex items-center gap-1 text-[#D4AF37] hover:text-white">
          {copied ? <><Check size={13} /> Copied</> : <><Copy size={13} /> Copy</>}
        </button>
      </div>
      <pre className="text-gray-300 text-xs whitespace-pre-wrap font-sans leading-relaxed max-h-48 overflow-y-auto">{text}</pre>
    </div>
  );
};

const MarketingOutputs: React.FC<{ property: PropertyData }> = ({ property }) => {
  const downloadFlyer = () => {
    const win = window.open('', '_blank');
    if (!win) return;
    win.document.write(`<html><head><title>${property.property_name} Flyer</title>
      <style>body{font-family:Georgia,serif;color:#222;padding:40px;max-width:800px;margin:auto}
      h1{color:#1a1a1a;border-bottom:3px solid #D4AF37;padding-bottom:8px}
      .gold{color:#b8941f}.grid{display:flex;gap:30px;flex-wrap:wrap;margin:20px 0}
      .stat{font-size:14px}.rate{font-size:28px;color:#b8941f;font-weight:bold}
      img{width:48%;border-radius:8px;margin:1%}</style></head><body>
      <p class="gold" style="letter-spacing:3px;text-transform:uppercase;font-size:12px">Atlanta VIP Retreats</p>
      <h1>${property.property_name}</h1>
      <p>${property.property_address || 'Atlanta, GA'}</p>
      <div class="grid">
        <span class="stat"><b>${property.bedrooms || 0}</b> Bedrooms</span>
        <span class="stat"><b>${property.bathrooms || 0}</b> Bathrooms</span>
        <span class="stat"><b>${property.parking || 0}</b> Parking</span>
        <span class="stat"><b>${property.office || 0}</b> Office</span>
      </div>
      <p class="rate">From $${property.nightly_rate || 0}/night</p>
      <p>${property.description || ''}</p>
      <h3 class="gold">Amenities</h3><p>${property.amenities || ''}</p>
      ${(property as any).photos ? (property as any).photos.slice(0, 4).map((p: string) => `<img src="${p}"/>`).join('') : ''}
      <p style="margin-top:30px;color:#888;font-size:12px">Inquire today · stay@atlantavipretreats.com · (404) 555-0188</p>
      </body></html>`);
    win.document.close();
    win.print();
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-3">
        <button onClick={downloadFlyer} className="flex items-center gap-2 bg-[#D4AF37] text-black px-5 py-2.5 rounded-lg font-medium hover:bg-[#c39e2e]"><FileDown size={16} /> Generate PDF Flyer</button>
      </div>
      <div className="grid lg:grid-cols-2 gap-4">
        <CopyBlock icon={Globe} title="Website Listing" text={websiteListing(property)} />
        <CopyBlock icon={FileText} title="Airbnb Description" text={airbnbDescription(property)} />
        <CopyBlock icon={FileText} title="VRBO Description" text={vrboDescription(property)} />
        <CopyBlock icon={FileText} title="Booking.com Description" text={bookingDescription(property)} />
        <CopyBlock icon={Share2} title="Social Media Caption" text={socialCaption(property)} />
        <CopyBlock icon={Package} title="Owner Packet" text={ownerPacket(property)} />
        <CopyBlock icon={ScrollText} title="Management Agreement Draft" text={managementAgreement(property)} />
      </div>
    </div>
  );
};

export default MarketingOutputs;
