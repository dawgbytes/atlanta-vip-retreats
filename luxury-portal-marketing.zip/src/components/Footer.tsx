import React from 'react';
import { Link } from 'react-router-dom';
import { Phone, Mail, MapPin } from 'lucide-react';

const Footer: React.FC = () => (
  <footer className="bg-[#111] text-gray-400 pt-16 pb-8 border-t border-[#D4AF37]/20">
    <div className="max-w-7xl mx-auto px-5 grid md:grid-cols-4 gap-10">
      <div>
        <h3 className="font-serif text-xl text-[#D4AF37] mb-3">Atlanta VIP Retreats</h3>
        <p className="text-sm leading-relaxed">Curated luxury homes, concierge support, and transportation coordination for Atlanta's most important moments.</p>
      </div>
      <div>
        <h4 className="text-white font-medium mb-3 text-sm uppercase tracking-wider">Explore</h4>
        <ul className="space-y-2 text-sm">
          <li><Link to="/properties" className="hover:text-[#D4AF37]">Properties</Link></li>
          <li><Link to="/world-cup" className="hover:text-[#D4AF37]">World Cup 2026</Link></li>
          <li><Link to="/concierge" className="hover:text-[#D4AF37]">Concierge</Link></li>
          <li><Link to="/transportation" className="hover:text-[#D4AF37]">Transportation</Link></li>
        </ul>
      </div>
      <div>
        <h4 className="text-white font-medium mb-3 text-sm uppercase tracking-wider">Partners</h4>
        <ul className="space-y-2 text-sm">
          <li><Link to="/owners" className="hover:text-[#D4AF37]">For Owners</Link></li>
          <li><Link to="/portal" className="hover:text-[#D4AF37]">Owner Portal</Link></li>
          <li><Link to="/contact" className="hover:text-[#D4AF37]">Contact Us</Link></li>
        </ul>
      </div>
      <div>
        <h4 className="text-white font-medium mb-3 text-sm uppercase tracking-wider">Contact</h4>
        <ul className="space-y-2 text-sm">
          <li className="flex items-center gap-2"><Phone size={14} className="text-[#D4AF37]" /> (404) 555-0188</li>
          <li className="flex items-center gap-2"><Mail size={14} className="text-[#D4AF37]" /> stay@atlantavipretreats.com</li>
          <li className="flex items-center gap-2"><MapPin size={14} className="text-[#D4AF37]" /> Atlanta, Georgia</li>
        </ul>
      </div>
    </div>
    <div className="max-w-7xl mx-auto px-5 mt-12 pt-6 border-t border-white/10 text-xs flex flex-col md:flex-row justify-between gap-2">
      <span>© {new Date().getFullYear()} Atlanta VIP Retreats. All rights reserved.</span>
      <span>Luxury Short-Term Rentals · Concierge · Transportation</span>
    </div>
  </footer>
);

export default Footer;
