import React from 'react';
import { Link } from 'react-router-dom';
import Layout from '@/components/Layout';
import PropertyCard from '@/components/PropertyCard';
import ContactForm from '@/components/ContactForm';
import { IMG } from '@/lib/images';
import { Plane, ShoppingBag, Shirt, ChefHat, CalendarClock, Sparkles, ArrowRight, Trophy } from 'lucide-react';

const concierge = [
  { icon: Plane, t: 'Airport Pickup Coordination', d: 'Seamless arrivals with private transportation arranged before you land.' },
  { icon: ShoppingBag, t: 'Grocery Stocking', d: 'Arrive to a fully stocked kitchen tailored to your preferences.' },
  { icon: Shirt, t: 'Laundry & Dry Cleaning', d: 'Coordinated pickup and delivery throughout your stay.' },
  { icon: ChefHat, t: 'Private Chef Referrals', d: 'In-home culinary experiences from vetted Atlanta chefs.' },
  { icon: CalendarClock, t: 'Event Transportation', d: 'Reliable rides to matches, meetings, and private events.' },
  { icon: Sparkles, t: 'Housekeeping Coordination', d: 'Professional cleaning scheduled around your itinerary.' },
];
const future = ['Stadium District', 'Midtown', 'Buckhead', 'Sandy Springs', 'Dunwoody'];

const AppLayout: React.FC = () => {
  return (
    <Layout>
      <section className="relative min-h-[88vh] flex items-center">
        <img src={IMG.hero} alt="Atlanta" className="absolute inset-0 w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-r from-black/85 via-black/60 to-black/30" />
        <div className="relative max-w-7xl mx-auto px-5 py-24">
          <span className="text-[#D4AF37] tracking-[0.3em] text-xs uppercase">Atlanta · Georgia</span>
          <h1 className="font-serif text-4xl md:text-6xl text-white mt-4 max-w-3xl leading-tight">Luxury Atlanta Stays for World Cup, Corporate Travel & Private Events</h1>
          <p className="text-gray-300 text-lg mt-6 max-w-2xl">Curated homes, concierge support, and transportation coordination for visitors coming to Atlanta's biggest events.</p>
          <div className="flex flex-wrap gap-4 mt-9">
            <Link to="/contact" className="bg-[#D4AF37] text-black font-medium px-7 py-3.5 rounded-lg hover:bg-[#c39e2e] transition-colors flex items-center gap-2">Inquire About a Stay <ArrowRight size={18} /></Link>
            <Link to="/owners" className="border border-white/40 text-white px-7 py-3.5 rounded-lg hover:bg-white hover:text-black transition-colors">Feature Your Property</Link>
          </div>
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-5 py-20">
        <div className="text-center mb-12">
          <span className="text-[#D4AF37] tracking-[0.3em] text-xs uppercase">Our Portfolio</span>
          <h2 className="font-serif text-3xl md:text-4xl text-white mt-3">Featured Properties</h2>
        </div>
        <div className="grid md:grid-cols-2 gap-8">
          <PropertyCard name="Dunwoody Executive Retreat" location="Chamblee Dunwoody Road, Dunwoody" image={IMG.homeExt1} status="Available for inquiry" beds={6} baths={4} parking={4} to="/properties/dunwoody" rate={895} />
          <PropertyCard name="Upper Westside Executive Retreat" location="Defoor Ave, West Midtown" image={IMG.homeExt2} status="Coming Soon" beds={5} baths={4} parking={3} to="/properties/upper-westside" />
        </div>
        <div className="mt-12">
          <h3 className="font-serif text-2xl text-white text-center mb-6">Future Atlanta Locations</h3>
          <div className="flex flex-wrap justify-center gap-3">
            {future.map((f) => <span key={f} className="px-5 py-2.5 rounded-full bg-[#1f1f1f] border border-[#D4AF37]/30 text-gray-300 text-sm">{f}</span>)}
          </div>
        </div>
      </section>

      <section className="relative py-24">
        <img src={IMG.stadium} alt="Stadium" className="absolute inset-0 w-full h-full object-cover" />
        <div className="absolute inset-0 bg-black/80" />
        <div className="relative max-w-5xl mx-auto px-5 text-center">
          <Trophy className="text-[#D4AF37] mx-auto mb-4" size={40} />
          <span className="text-[#D4AF37] tracking-[0.3em] text-xs uppercase">FIFA World Cup 2026</span>
          <h2 className="font-serif text-3xl md:text-5xl text-white mt-3">Atlanta Hosts 8 World Cup Matches</h2>
          <p className="text-gray-300 text-lg mt-6 max-w-3xl mx-auto">Mercedes-Benz Stadium welcomes the world for eight FIFA World Cup matches in 2026, driving unprecedented demand for premium accommodations. Secure your luxury stay early.</p>
          <Link to="/world-cup" className="inline-flex items-center gap-2 mt-8 bg-[#D4AF37] text-black font-medium px-7 py-3.5 rounded-lg hover:bg-[#c39e2e] transition-colors">Inquire for World Cup Housing <ArrowRight size={18} /></Link>
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-5 py-20">
        <div className="text-center mb-12">
          <span className="text-[#D4AF37] tracking-[0.3em] text-xs uppercase">White-Glove Service</span>
          <h2 className="font-serif text-3xl md:text-4xl text-white mt-3">Concierge Services</h2>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {concierge.map((c) => (
            <div key={c.t} className="bg-[#1f1f1f] border border-white/10 rounded-xl p-7 hover:border-[#D4AF37]/50 transition-colors">
              <div className="w-12 h-12 rounded-lg bg-[#D4AF37]/15 flex items-center justify-center mb-4"><c.icon className="text-[#D4AF37]" size={22} /></div>
              <h3 className="text-white font-medium text-lg mb-2">{c.t}</h3>
              <p className="text-gray-400 text-sm leading-relaxed">{c.d}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="bg-[#1a1a1a] py-20">
        <div className="max-w-7xl mx-auto px-5 grid md:grid-cols-2 gap-12 items-center">
          <img src={IMG.interior2} alt="Interior" className="rounded-xl object-cover h-80 w-full" />
          <div>
            <span className="text-[#D4AF37] tracking-[0.3em] text-xs uppercase">Partner With Us</span>
            <h2 className="font-serif text-3xl md:text-4xl text-white mt-3 mb-4">For Property Owners</h2>
            <p className="text-gray-300 leading-relaxed mb-6">We help owners prepare, position, price, and market homes for event-based and luxury short-term rental demand. From World Cup 2026 to corporate travel, our team turns your property into a high-performing asset.</p>
            <Link to="/owners" className="inline-flex items-center gap-2 bg-[#D4AF37] text-black font-medium px-7 py-3.5 rounded-lg hover:bg-[#c39e2e] transition-colors">Learn More <ArrowRight size={18} /></Link>
          </div>
        </div>
      </section>

      <section className="max-w-3xl mx-auto px-5 py-20">
        <div className="text-center mb-10">
          <span className="text-[#D4AF37] tracking-[0.3em] text-xs uppercase">Get In Touch</span>
          <h2 className="font-serif text-3xl md:text-4xl text-white mt-3">Begin Your Atlanta Experience</h2>
        </div>
        <ContactForm source="home-contact" />
      </section>
    </Layout>
  );
};

export default AppLayout;
