import React from 'react';
import Navbar from './Navbar';
import Footer from './Footer';

const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <div className="min-h-screen bg-[#161616] text-gray-100 font-sans">
    <Navbar />
    <main>{children}</main>
    <Footer />
  </div>
);

export default Layout;
