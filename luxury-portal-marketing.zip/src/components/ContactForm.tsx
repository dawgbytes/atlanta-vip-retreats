import React, { useState } from 'react';
import { supabase } from '@/lib/supabase';
import { Check, Loader2 } from 'lucide-react';

interface Props {
  defaultInterest?: string;
  compact?: boolean;
  source?: string;
}

const ContactForm: React.FC<Props> = ({ defaultInterest = 'stay', compact, source = 'contact-form' }) => {
  const [form, setForm] = useState({ name: '', email: '', phone: '', interest: defaultInterest, message: '' });
  const [status, setStatus] = useState<'idle' | 'sending' | 'done' | 'error'>('idle');

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.email) return;
    setStatus('sending');
    try {
      await supabase.from('leads').insert({
        name: form.name, email: form.email, phone: form.phone,
        interest: form.interest, message: form.message,
      });
      await fetch('https://famous.ai/api/crm/6a211cfc56545a9a21240ba2/subscribe', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: form.email, name: form.name, source, tags: ['lead', form.interest] }),
      });
      setStatus('done');
    } catch {
      setStatus('error');
    }
  };

  if (status === 'done') {
    return (
      <div className="bg-[#D4AF37]/10 border border-[#D4AF37]/40 rounded-xl p-10 text-center">
        <div className="w-14 h-14 rounded-full bg-[#D4AF37] flex items-center justify-center mx-auto mb-4"><Check className="text-black" /></div>
        <h3 className="font-serif text-2xl text-white mb-2">Thank You</h3>
        <p className="text-gray-300">Our team will reach out within 24 hours to personally assist with your request.</p>
      </div>
    );
  }

  const input = "w-full bg-[#1f1f1f] border border-white/15 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:border-[#D4AF37] focus:outline-none transition-colors";

  return (
    <form onSubmit={submit} className="space-y-4">
      <div className={compact ? '' : 'grid md:grid-cols-2 gap-4'}>
        <input className={input} placeholder="Full Name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required />
        <input className={input} type="email" placeholder="Email Address" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} required />
      </div>
      <div className={compact ? '' : 'grid md:grid-cols-2 gap-4'}>
        <input className={input} placeholder="Phone Number" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
        <select className={input} value={form.interest} onChange={(e) => setForm({ ...form, interest: e.target.value })}>
          <option value="stay">Interested in a Stay</option>
          <option value="property owner">Property Owner</option>
          <option value="transportation">Transportation</option>
          <option value="partnership">Partnership</option>
        </select>
      </div>
      <textarea className={input} rows={4} placeholder="How can we help you?" value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} />
      {status === 'error' && <p className="text-red-400 text-sm">Something went wrong. Please try again.</p>}
      <button disabled={status === 'sending'} className="w-full bg-[#D4AF37] text-black font-medium py-3.5 rounded-lg hover:bg-[#c39e2e] transition-colors flex items-center justify-center gap-2 disabled:opacity-60">
        {status === 'sending' ? <><Loader2 className="animate-spin" size={18} /> Sending...</> : 'Submit Inquiry'}
      </button>
    </form>
  );
};

export default ContactForm;
