import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X } from 'lucide-react';

const links = [
  { to: '/', label: 'Home' },
  { to: '/properties', label: 'Properties' },
  { to: '/world-cup', label: 'World Cup 2026' },
  { to: '/concierge', label: 'Concierge' },
  { to: '/transportation', label: 'Transportation' },
  { to: '/owners', label: 'For Owners' },
  { to: '/contact', label: 'Contact' },
];

const Navbar: React.FC = () => {
  const [open, setOpen] = useState(false);
  const loc = useLocation();
  return (
    <header className="sticky top-0 z-50 bg-[#1a1a1a]/95 backdrop-blur border-b border-[#D4AF37]/20">
      <div className="max-w-7xl mx-auto px-5 flex items-center justify-between h-20">
        <Link to="/" className="flex flex-col leading-none">
          <span className="font-serif text-xl md:text-2xl text-[#D4AF37] tracking-wide">Atlanta VIP Retreats</span>
          <span className="text-[10px] tracking-[0.3em] text-gray-400 uppercase">Luxury Hospitality</span>
        </Link>
        <nav className="hidden lg:flex items-center gap-7">
          {links.map((l) => (
            <Link key={l.to} to={l.to} className={`text-sm tracking-wide transition-colors ${loc.pathname === l.to ? 'text-[#D4AF37]' : 'text-gray-200 hover:text-[#D4AF37]'}`}>{l.label}</Link>
          ))}
          <Link to="/portal" className="ml-2 px-4 py-2 text-sm border border-[#D4AF37] text-[#D4AF37] rounded hover:bg-[#D4AF37] hover:text-black transition-colors">Owner Portal</Link>
        </nav>
        <button className="lg:hidden text-[#D4AF37]" onClick={() => setOpen(!open)}>{open ? <X /> : <Menu />}</button>
      </div>
      {open && (
        <nav className="lg:hidden bg-[#1a1a1a] border-t border-[#D4AF37]/20 px-5 py-4 flex flex-col gap-3">
          {links.map((l) => (
            <Link key={l.to} to={l.to} onClick={() => setOpen(false)} className="text-gray-200 hover:text-[#D4AF37] py-1">{l.label}</Link>
          ))}
          <Link to="/portal" onClick={() => setOpen(false)} className="text-[#D4AF37] py-1 font-medium">Owner Portal</Link>
        </nav>
      )}
    </header>
  );
};

export default Navbar;
