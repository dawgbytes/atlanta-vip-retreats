import React, { useState } from 'react';
import { supabase } from '@/lib/supabase';
import { Upload, X, Loader2 } from 'lucide-react';

interface Props {
  photos: string[];
  onChange: (photos: string[]) => void;
}

const PhotoUploader: React.FC<Props> = ({ photos, onChange }) => {
  const [uploading, setUploading] = useState(false);

  const handleFiles = async (files: FileList | null) => {
    if (!files) return;
    setUploading(true);
    const urls: string[] = [];
    for (const file of Array.from(files)) {
      const path = `${Date.now()}-${Math.random().toString(36).slice(2)}-${file.name}`;
      const { error } = await supabase.storage.from('property-photos').upload(path, file);
      if (!error) {
        const { data } = supabase.storage.from('property-photos').getPublicUrl(path);
        urls.push(data.publicUrl);
      }
    }
    onChange([...photos, ...urls]);
    setUploading(false);
  };

  return (
    <div>
      <label className="block border-2 border-dashed border-white/20 rounded-xl p-8 text-center cursor-pointer hover:border-[#D4AF37]/50 transition-colors">
        <input type="file" multiple accept="image/*" className="hidden" onChange={(e) => handleFiles(e.target.files)} />
        {uploading ? <Loader2 className="animate-spin text-[#D4AF37] mx-auto" /> : <Upload className="text-[#D4AF37] mx-auto" />}
        <p className="text-gray-400 text-sm mt-2">{uploading ? 'Uploading...' : 'Click to upload property photos'}</p>
      </label>
      {photos.length > 0 && (
        <div className="grid grid-cols-3 sm:grid-cols-4 gap-3 mt-4">
          {photos.map((p, i) => (
            <div key={i} className="relative group">
              <img src={p} alt={`photo ${i}`} className="h-24 w-full object-cover rounded-lg" />
              <button type="button" onClick={() => onChange(photos.filter((_, idx) => idx !== i))} className="absolute top-1 right-1 bg-black/70 rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity">
                <X size={14} className="text-white" />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default PhotoUploader;
