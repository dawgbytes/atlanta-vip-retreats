import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { ThemeProvider } from "@/components/theme-provider";
import Index from "./pages/Index";
import Properties from "./pages/Properties";
import PropertyDetail from "./pages/PropertyDetail";
import DbProperty from "./pages/DbProperty";
import WorldCup from "./pages/WorldCup";
import Concierge from "./pages/Concierge";
import Transportation from "./pages/Transportation";
import Owners from "./pages/Owners";
import Contact from "./pages/Contact";
import Portal from "./pages/Portal";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <ThemeProvider defaultTheme="dark">
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<Index />} />
            <Route path="/properties" element={<Properties />} />
            <Route path="/properties/db/:id" element={<DbProperty />} />
            <Route path="/properties/:slug" element={<PropertyDetail />} />
            <Route path="/world-cup" element={<WorldCup />} />
            <Route path="/concierge" element={<Concierge />} />
            <Route path="/transportation" element={<Transportation />} />
            <Route path="/owners" element={<Owners />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/portal" element={<Portal />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </TooltipProvider>
    </QueryClientProvider>
  </ThemeProvider>
);

export default App;
