export interface PropertyData {
  property_name: string;
  property_address?: string;
  owner_name?: string;
  manager_name?: string;
  bedrooms?: number;
  bathrooms?: number;
  office?: number;
  parking?: number;
  amenities?: string;
  description?: string;
  nightly_rate?: number;
  cleaning_fee?: number;
  transportation_available?: boolean;
  laundry_available?: boolean;
  concierge_available?: boolean;
  status?: string;
}

const services = (p: PropertyData) => {
  const s: string[] = [];
  if (p.transportation_available) s.push('private transportation coordination');
  if (p.laundry_available) s.push('on-site laundry');
  if (p.concierge_available) s.push('dedicated concierge support');
  return s;
};

export function airbnbDescription(p: PropertyData): string {
  const svc = services(p);
  return `${p.property_name} — A refined Atlanta retreat${p.property_address ? ` in ${p.property_address}` : ''}.

Welcome to an elevated stay designed for executives, families, and group travelers. This ${p.bedrooms || 0}-bedroom, ${p.bathrooms || 0}-bath home offers ${p.parking || 0} parking spaces${p.office ? ` and ${p.office} dedicated office space(s)` : ''}.

${p.description || 'Thoughtfully appointed interiors, generous living areas, and a prime location make this the perfect base for your Atlanta visit.'}

Amenities: ${p.amenities || 'Premium furnishings, high-speed WiFi, fully equipped kitchen.'}
${svc.length ? `\nGuest services available: ${svc.join(', ')}.` : ''}

Rate: $${p.nightly_rate || 0}/night${p.cleaning_fee ? ` + $${p.cleaning_fee} cleaning fee` : ''}. Book your luxury Atlanta experience today.`;
}

export function vrboDescription(p: PropertyData): string {
  return `LUXURY ATLANTA HOME — ${p.property_name.toUpperCase()}

Ideal for World Cup visitors, corporate travelers, and private events. ${p.bedrooms || 0} bedrooms | ${p.bathrooms || 0} bathrooms | ${p.parking || 0} parking.

${p.description || 'Spacious, elegant, and impeccably maintained.'}

Featured amenities: ${p.amenities || 'WiFi, full kitchen, premium linens, smart TV.'}
${services(p).length ? `Concierge-level services: ${services(p).join(', ')}.` : ''}

Nightly rate from $${p.nightly_rate || 0}. Inquire now for available dates.`;
}

export function bookingDescription(p: PropertyData): string {
  return `${p.property_name} offers upscale accommodation${p.property_address ? ` in ${p.property_address}` : ''}, featuring ${p.bedrooms || 0} bedrooms and ${p.bathrooms || 0} bathrooms. ${p.description || 'Guests enjoy elegant interiors and a convenient Atlanta location.'} Amenities include ${p.amenities || 'free WiFi, parking, and a fully equipped kitchen'}. ${services(p).length ? `Additional services: ${services(p).join(', ')}.` : ''} Priced from $${p.nightly_rate || 0} per night.`;
}

export function socialCaption(p: PropertyData): string {
  return `Your luxury Atlanta escape awaits at ${p.property_name}. ${p.bedrooms || 0}BR | ${p.bathrooms || 0}BA of curated comfort — perfect for World Cup 2026, corporate stays & private events. Concierge-level service, Southern hospitality. DM to inquire. #AtlantaVIPRetreats #LuxuryStays #WorldCup2026 #AtlantaTravel`;
}

export function websiteListing(p: PropertyData): string {
  return `${p.property_name} | ${p.bedrooms || 0} Bed · ${p.bathrooms || 0} Bath · Sleeps group travelers
${p.property_address || 'Atlanta, GA'}
From $${p.nightly_rate || 0}/night · Status: ${p.status || 'Coming Soon'}

${p.description || 'A premier luxury rental managed by Atlanta VIP Retreats.'}`;
}

export function ownerPacket(p: PropertyData): string {
  return `ATLANTA VIP RETREATS — OWNER PACKET
Property: ${p.property_name}
Address: ${p.property_address || 'TBD'}
Owner: ${p.owner_name || 'TBD'} | Manager: ${p.manager_name || 'Atlanta VIP Retreats'}

POSITIONING SUMMARY
This property is positioned as a luxury short-term rental targeting World Cup 2026 visitors, corporate travelers, and private event groups. Suggested nightly rate: $${p.nightly_rate || 0} (+ $${p.cleaning_fee || 0} cleaning fee).

PROPERTY PROFILE
- Bedrooms: ${p.bedrooms || 0}
- Bathrooms: ${p.bathrooms || 0}
- Office Spaces: ${p.office || 0}
- Parking: ${p.parking || 0}
- Amenities: ${p.amenities || 'N/A'}
- Transportation: ${p.transportation_available ? 'Available' : 'Not included'}
- Laundry: ${p.laundry_available ? 'Available' : 'Not included'}
- Concierge: ${p.concierge_available ? 'Available' : 'Not included'}

OUR SERVICES
Atlanta VIP Retreats prepares, positions, prices, and markets your home across Airbnb, VRBO, and Booking.com while coordinating concierge and transportation services for guests.`;
}

export function managementAgreement(p: PropertyData): string {
  const date = new Date().toLocaleDateString();
  return `PROPERTY MANAGEMENT AGREEMENT (DRAFT)
Date: ${date}

This Agreement is entered into between ${p.owner_name || '[OWNER NAME]'} ("Owner") and Atlanta VIP Retreats ("Manager") regarding the property located at ${p.property_address || '[PROPERTY ADDRESS]'} ("the Property"), known as ${p.property_name}.

1. SERVICES. Manager shall market, list, and coordinate short-term rental operations for the Property, including guest communication, concierge coordination, and transportation support.

2. RATES & FEES. Base nightly rate: $${p.nightly_rate || 0}. Cleaning fee: $${p.cleaning_fee || 0}. Management commission and fee structure to be defined in Schedule A.

3. TERM. This Agreement shall remain in effect for an initial term of twelve (12) months and renew automatically unless terminated with thirty (30) days written notice.

4. RESPONSIBILITIES. Owner shall maintain the Property in rentable condition and provide accurate property information. Manager shall act in good faith to maximize occupancy and revenue.

5. THIS IS A NON-BINDING DRAFT for discussion purposes only and does not constitute a legal contract until executed by both parties.

_______________________        _______________________
Owner Signature                Manager Signature`;
}
