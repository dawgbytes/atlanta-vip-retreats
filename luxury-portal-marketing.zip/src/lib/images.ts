export const IMG = {
  hero: 'https://d64gsuwffb70l.cloudfront.net/6a211cfc56545a9a21240ba2_1780555155492_1a59f9df.jpg',
  homeExt1: 'https://d64gsuwffb70l.cloudfront.net/6a211cfc56545a9a21240ba2_1780555175609_ffa83ff0.jpg',
  homeExt2: 'https://d64gsuwffb70l.cloudfront.net/6a211cfc56545a9a21240ba2_1780555179206_5d5898ae.png',
  interior1: 'https://d64gsuwffb70l.cloudfront.net/6a211cfc56545a9a21240ba2_1780555200454_fb8c48b7.jpg',
  interior2: 'https://d64gsuwffb70l.cloudfront.net/6a211cfc56545a9a21240ba2_1780555213951_964ae2f4.png',
  interior3: 'https://d64gsuwffb70l.cloudfront.net/6a211cfc56545a9a21240ba2_1780555203303_edd96ade.jpg',
  interior4: 'https://d64gsuwffb70l.cloudfront.net/6a211cfc56545a9a21240ba2_1780555223552_ab86b05c.png',
  stadium: 'https://d64gsuwffb70l.cloudfront.net/6a211cfc56545a9a21240ba2_1780555240903_0ff6925d.jpg',
  transport: 'https://d64gsuwffb70l.cloudfront.net/6a211cfc56545a9a21240ba2_1780555275614_b5ffe2be.png',
  chef: 'https://d64gsuwffb70l.cloudfront.net/6a211cfc56545a9a21240ba2_1780555308970_caeee329.png',
};

export const BOOKING_URL = 'https://famous.ai/api/crm/6a211cfc56545a9a21240ba2/calendar/public?calendarId=54f8676c-d96d-4fe1-ab52-dd064b4fa499&view=booking';
