import { createClient } from '@supabase/supabase-js';


// Initialize database client
const supabaseUrl = 'https://afraiisnyialehcllrko.databasepad.com';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjAyNDIzYWE3LTk5YTgtNGE2MS04ZDM1LWY1Nzg5NjUzNmZjOCJ9.eyJwcm9qZWN0SWQiOiJhZnJhaWlzbnlpYWxlaGNsbHJrbyIsInJvbGUiOiJhbm9uIiwiaWF0IjoxNzgwNTU1MDUwLCJleHAiOjIwOTU5MTUwNTAsImlzcyI6ImZhbW91cy5kYXRhYmFzZXBhZCIsImF1ZCI6ImZhbW91cy5jbGllbnRzIn0.l4UZteDFyGiGKOCQ5zeb6bTjceUioL1Kd9AQN4gQB3o';
const supabase = createClient(supabaseUrl, supabaseKey);


export { supabase };